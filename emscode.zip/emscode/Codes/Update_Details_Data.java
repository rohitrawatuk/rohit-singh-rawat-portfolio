
 
package employee.management.system;

import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
import java.sql.*;


public class Update_Details_Data extends JFrame implements ActionListener{
    JLabel l1,l2,l3,l4,l5,l6,l7,l8,l9,l10,l11,l12,l13;
    JButton bt1,bt2;
    JPanel p1,p2,p3;
    JTextField tf1,tf2,tf3,tf4,tf5,tf6,tf7,tf8,tf9,tf10;
    Font f,f1;
    Choice ch;

    Update_Details_Data()
    {
        super("Update Employee");
        setLocation(200,0);
        setSize(950,750);
        
        f=new Font("Arial",Font.BOLD,25);
        f1=new Font("Arial",Font.BOLD,18);
        
        ch=new Choice();
        
        try{
            Conn obj=new Conn();
            String q="select EmpID from employees";
            ResultSet rest=obj.s.executeQuery(q);
            while(rest.next())
            {
                ch.add(rest.getString("EmpID"));
            }
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
        
        l1=new JLabel("Update Employee");
         l2=new JLabel("Name");
          l3=new JLabel("Father's Name");
           l4=new JLabel("Age");
            l5=new JLabel("Date of Birth");
             l6=new JLabel("Address");
              l7=new JLabel("Phone");
               l8=new JLabel("Email");
                l9=new JLabel("Education");
                 l10=new JLabel("Job Post");
                  l11=new JLabel("Aadhar");
                   l12=new JLabel("Employee ID");
                   
                   
                   tf1=new JTextField();
                    tf2=new JTextField();
                     tf3=new JTextField();
                      tf4=new JTextField();
                       tf5=new JTextField();
                        tf6=new JTextField();
                         tf7=new JTextField();
                          tf8=new JTextField();
                           tf9=new JTextField();
                            tf10=new JTextField();
                            
                            bt1=new JButton("Update Data");
                            bt2=new JButton("Back");
                            
                            l1.setHorizontalAlignment(JLabel.CENTER);
                            
                            bt1.addActionListener(this);
                            bt2.addActionListener(this);
                            
                            l1.setFont(f);
                             l2.setFont(f1);
                              l3.setFont(f1);
                               l4.setFont(f1);
                                l5.setFont(f1);
                                 l6.setFont(f1);
                                  l7.setFont(f1);
                                   l8.setFont(f1);
                                    l9.setFont(f1);
                                     l10.setFont(f1);
                                      l11.setFont(f1);
                                       l12.setFont(f1);
                     ch.setFont(f1);
                     
                     tf1.setFont(f1);
                     tf2.setFont(f1);
                     tf3.setFont(f1);
                     tf4.setFont(f1);
                     tf5.setFont(f1);
                     tf6.setFont(f1);
                     tf7.setFont(f1);
                     tf8.setFont(f1);
                     tf9.setFont(f1);
                     tf10.setFont(f1);
                     
                     bt1.setFont(f1);
                     bt2.setFont(f1);
                     
                     bt1.setBackground(Color.black);
                     bt2.setBackground(Color.red);
                     
                     bt1.setForeground(Color.white);
                     bt2.setForeground(Color.white);
                     
                     p1=new JPanel();
                     p1.setLayout(new GridLayout(1,1,10,10));
                     p1.add(l1);
                     
                     p2=new JPanel();
                     p2.setLayout(new GridLayout(12,2,10,10));
                     
                     p2.add(l12);
                     p2.add(ch);
                     p2.add(l2);
                     p2.add(tf1);
                     p2.add(l3);
                     p2.add(tf2);
                     p2.add(l4);
                     p2.add(tf3);
                     p2.add(l5);
                     p2.add(tf4);
                     p2.add(l6);
                     p2.add(tf5);
                     p2.add(l7);
                     p2.add(tf6);
                     p2.add(l8);
                     p2.add(tf7);
                     p2.add(l9);
                     p2.add(tf8);
                     p2.add(l10);
                     p2.add(tf9);
                     p2.add(l11);
                     p2.add(tf10);
                     p2.add(bt1);
                     p2.add(bt2);
                     
                     p3=new JPanel();
                     p3.setLayout(new GridLayout(1,1,10,10));
                      
                     ImageIcon img=new ImageIcon(ClassLoader.getSystemResource("icons/details.jpg"));
                     Image img1=img.getImage().getScaledInstance(400, 600,Image.SCALE_DEFAULT);
                     ImageIcon ic1=new ImageIcon(img1);
                     l13=new JLabel(ic1);
                     
                     p3.add(l13);
                     
                     setLayout(new BorderLayout(10,10));
                     add(p1,"North");
                     add(p2,"Center");
                     add(p3,"West");
                     
                     ch.addMouseListener(new MouseAdapter()
                             {
                                 @Override
                                 public void mouseClicked(MouseEvent arg0)
                                 {
                                     try{
                                         Conn obj2 =new Conn();
                                         String EmpID=ch.getSelectedItem();
                                         String q1="select * from employees where EmpID='"+EmpID+"'";
                                         ResultSet rest1= obj2.s.executeQuery(q1);
                                         while(rest1.next())
                                         {
               tf1.setText(rest1.getString("name"));
                tf2.setText(rest1.getString("Fname"));
                tf3.setText(rest1.getString("Age"));
                tf4.setText(rest1.getString("DOB"));
                tf5.setText(rest1.getString("Address"));
                tf6.setText(rest1.getString("PhoneNo"));
                tf7.setText(rest1.getString("Email"));
                tf8.setText(rest1.getString("Education"));
                tf9.setText(rest1.getString("JobPost"));
                tf10.setText(rest1.getString("AdhaarNo"));
               
                                         }
                                     }
                                     catch(Exception exx)
                                     {
                                         exx.printStackTrace();
                                     }
                                 }
                                         
                             });
    }
    public void actionPerformed(ActionEvent e)
    {
        String id=ch.getSelectedItem();
        String name=tf1.getText();
        String Fname=tf2.getText();
        String Age=tf3.getText();
        String DOB=tf4.getText();
        String Address=tf5.getText();
        String PhoneNo=tf6.getText();
        String Email=tf7.getText();
        String Education=tf8.getText();
        String JobPost=tf9.getText();
        String AdhaarNo=tf10.getText();
        
        if(e.getSource()==bt1)
        {
            try
            {
                Conn obj3=new Conn();
                String q1="update employees set name='"+name+"',Fname='"+Fname+"',Age='"+Age+"',DOB='"+DOB+"',Address='"+Address+"',PhoneNo='"+PhoneNo+"',Email='"+Email+"',Education='"+Education+"',JobPost='"+JobPost+"',AdhaarNo='"+AdhaarNo+"' where EmpID='"+id+"'";
               int aa=obj3.s.executeUpdate(q1);
               if(aa==1)
               {
                   JOptionPane.showMessageDialog(null,"your data sucessfully updated");
                   this.setVisible(false);
                   new Update_Details_Data();
                   
               }
               else{
                   JOptionPane.showMessageDialog(null, "Please! Fill all details carefully");
               }
                       
            }
            catch(Exception ee)
            {
                ee.printStackTrace();
            }
    }
        if(e.getSource()==bt2)
        {
            this.setVisible(false);
        }
    }
    public static void main(String args[])
    {
        new Update_Details_Data().setVisible(true);
    }
                     
    }
    
    
