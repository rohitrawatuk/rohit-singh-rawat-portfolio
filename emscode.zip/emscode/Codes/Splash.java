
package employee.management.system;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
public class Splash extends JFrame implements ActionListener{
    JPanel d1;
    Splash(){
        super("WELCOME TO EMPLOYEE MANAGEMENT SYSTEM APPLICATION");
        getContentPane().setBackground(Color.WHITE);
        setLayout(null);
        JLabel heading=new JLabel("EMPLOYEE MANAGEMENT SYSTEM");
        heading.setBounds(160,30,1200,60);
        heading.setFont(new Font("serif",Font.PLAIN,60));
        heading .setForeground(Color.RED);
        add(heading);
        ImageIcon i1=new ImageIcon(ClassLoader.getSystemResource("icons/me.jpg"));
        Image i2=i1.getImage().getScaledInstance(1550,800,Image.SCALE_DEFAULT);
        ImageIcon i3=new ImageIcon(i2);
        JLabel image=new JLabel(i3);
        image.setBounds(50,100,1250,550);
        add(image);
        JButton clickhere=new JButton("CLICK HERE TO CONTINUE");
        clickhere.setFont(new Font("serif",Font.BOLD,15));                               
        clickhere.setBounds(480,450,300,70);
        clickhere.setBackground(Color.BLACK);
        clickhere.setForeground(Color.WHITE);
        clickhere.addActionListener(this);
        image.add(clickhere);
        setSize(1550,800);
        setLocation(0,0);
        setVisible(true);
     
        
    }
    public void actionPerformed(ActionEvent ae)
    {
        setVisible(false);
        new login();
    }
        public static void main(String args[])
        {
            new Splash();
        }
    
}
 